<?php
/**
 * Sidebar V2 — Sticky Booking Sidebar (CRO Optimized)
 * Variables provided by layout-controller.php via extract()
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$wa_raw    = trim( (string) apply_filters( 'fts_whatsapp_number', '+201000479285' ) );
$wa_digits = preg_replace( '/\D+/', '', $wa_raw );
?>

<div class="fts-v2-sidebar-wrapper" id="fts-v2-booking-sidebar">
    <div class="fts-v2-sidebar-sticky">

        <div class="fts-v2-booking-card">

            <!-- 1. Price Header -->
            <div class="fts-v2-booking-price-top">
                <div class="fts-v2-booking-price-header">
                    <div class="fts-v2-booking-from"><?php echo esc_html__( 'From', 'fts' ); ?></div>
                    <?php if ( $avg_rating > 0 ) : ?>
                    <a class="fts-v2-booking-rating fts-v2-meta-tidx" href="#fts-v2-sec-reviews">
                        <i class="fa fa-star"></i> <?php echo esc_html( number_format( (float) $avg_rating, 1 ) ); ?>
                        <span>(<?php echo intval( $review_count ); ?>)</span>
                    </a>
                    <?php endif; ?>
                </div>
                <div class="fts-v2-booking-price-row">
                    <?php if ( $old_price > 0 ) : ?>
                        <span class="fts-v2-booking-old-price"><?php echo esc_html( wte_get_formated_price( $old_price ) ); ?></span>
                    <?php endif; ?>
                    <span class="fts-v2-booking-current-price"><?php echo esc_html( wte_get_formated_price( $display_price ) ); ?></span>
                    <span class="fts-v2-booking-per-person"><?php echo esc_html__( '/ person', 'fts' ); ?></span>
                </div>
                <?php if ( $discount_pct > 0 ) : ?>
                <div class="fts-v2-booking-save-badge"><?php echo esc_html__( 'SAVE', 'fts' ); ?> <?php echo intval( $discount_pct ); ?>%</div>
                <?php endif; ?>
            </div>

            <!-- 2. Social Proof Bar (removed) -->

            <!-- 3. Cancellation Policy (removed) -->

            <!-- 4. Calendar Accordion -->
            <div class="fts-v2-calendar-section fts-v2-cal-collapsed" id="fts-v2-cal-accordion">
                <button type="button" class="fts-v2-cal-toggle" id="fts-v2-cal-toggle">
                    <div class="fts-v2-cal-toggle-left">
                        <div class="fts-v2-cal-icon-wrap">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        </div>
                        <div class="fts-v2-cal-toggle-text">
                            <span class="fts-v2-cal-label"><?php echo esc_html__( 'Select Date', 'fts' ); ?></span>
                            <span class="fts-v2-cal-selected" id="fts-v2-cal-selected"><?php echo esc_html__( 'Tap to choose your travel date', 'fts' ); ?></span>
                        </div>
                    </div>
                    <svg class="fts-v2-cal-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                </button>
                <div class="fts-v2-cal-body" id="fts-v2-cal-body">
                    <div id="fts-v2-datepicker"></div>
                    <div class="fts-v2-calendar-legend">
                        <span class="fts-v2-legend-item fts-v2-legend-low"><span class="fts-v2-legend-dot"></span> <?php echo esc_html__( 'Low availability', 'fts' ); ?></span>
                        <span class="fts-v2-legend-item fts-v2-legend-best"><span class="fts-v2-legend-dot"></span> <?php echo esc_html__( 'Best price', 'fts' ); ?></span>
                    </div>
                </div>
            </div>

            <!-- 5. Travelers Accordion -->
            <div class="fts-v2-travelers-accordion fts-v2-trav-collapsed" id="fts-v2-travelers-accordion">
                <button type="button" class="fts-v2-trav-toggle" id="fts-v2-trav-toggle">
                    <div class="fts-v2-trav-toggle-left">
                        <div class="fts-v2-trav-icon-wrap">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        </div>
                        <div class="fts-v2-trav-toggle-text">
                            <span class="fts-v2-trav-label"><?php echo esc_html__( 'Travelers', 'fts' ); ?></span>
                            <span class="fts-v2-trav-summary" id="fts-v2-trav-summary"><?php echo esc_html__( '1 Adult', 'fts' ); ?></span>
                        </div>
                    </div>
                    <svg class="fts-v2-trav-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                </button>
                <div class="fts-v2-trav-body" id="fts-v2-trav-body">
                    <div class="fts-v2-trav-row">
                        <div class="fts-v2-trav-row-info">
                            <span class="fts-v2-trav-row-label"><?php echo esc_html__( 'Adults', 'fts' ); ?></span>
                            <span class="fts-v2-trav-row-hint"><?php echo esc_html__( 'Age 12+', 'fts' ); ?></span>
                        </div>
                        <div class="fts-v2-trav-row-counter">
                            <button type="button" class="fts-v2-trav-btn" data-type="adults" data-dir="minus">−</button>
                            <span class="fts-v2-trav-num" id="fts-v2-adults-count">1</span>
                            <button type="button" class="fts-v2-trav-btn" data-type="adults" data-dir="plus">+</button>
                        </div>
                    </div>
                    <div class="fts-v2-trav-row">
                        <div class="fts-v2-trav-row-info">
                            <span class="fts-v2-trav-row-label"><?php echo esc_html__( 'Children', 'fts' ); ?></span>
                            <span class="fts-v2-trav-row-hint"><?php echo esc_html__( 'Age 2–11', 'fts' ); ?></span>
                        </div>
                        <div class="fts-v2-trav-row-counter">
                            <button type="button" class="fts-v2-trav-btn" data-type="children" data-dir="minus">−</button>
                            <span class="fts-v2-trav-num" id="fts-v2-children-count">0</span>
                            <button type="button" class="fts-v2-trav-btn" data-type="children" data-dir="plus">+</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 6. Trip Highlights -->
            <?php
                $sb_items = array();

                if ( ! empty( $duration_text ) ) {
                    $sb_items[] = array(
                        'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
                        'text' => __( 'Duration', 'fts' ) . ' ' . esc_html( $duration_text ),
                    );
                }

                $sb_lang   = '';
                $sb_pickup = '';
                if ( isset( $trip_facts_items ) && is_array( $trip_facts_items ) ) {
                    foreach ( $trip_facts_items as $sbit ) {
                        if ( ! is_array( $sbit ) ) continue;
                        $sblbl = strtolower( trim( (string) ( $sbit['label'] ?? '' ) ) );
                        $sbval = trim( (string) ( $sbit['value'] ?? '' ) );
                        if ( $sblbl === '' || $sbval === '' ) continue;
                        if ( $sb_lang === '' && ( strpos( $sblbl, 'language' ) !== false || strpos( $sblbl, 'languages' ) !== false || strpos( $sblbl, 'لغة' ) !== false ) ) $sb_lang = $sbval;
                        if ( $sb_pickup === '' && ( strpos( $sblbl, 'pickup' ) !== false || strpos( $sblbl, 'meeting' ) !== false || strpos( $sblbl, 'start' ) !== false || strpos( $sblbl, 'استلام' ) !== false ) ) $sb_pickup = $sbval;
                    }
                }

                if ( $sb_lang !== '' ) {
                    $sb_items[] = array(
                        'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8l6 6"/><path d="M4 14l6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="M22 22l-5-10-5 10"/><path d="M14 18h6"/></svg>',
                        'text' => __( 'Live tour guide', 'fts' ) . ' — ' . $sb_lang,
                    );
                }

                if ( $sb_pickup !== '' ) {
                    $sb_items[] = array(
                        'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9L18 10l-2-4H7L5 10l-2.5 1.1C1.7 11.3 1 12.1 1 13v3c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><path d="M5 10h14"/></svg>',
                        'text' => __( 'Pickup included', 'fts' ),
                    );
                }

                $sb_ci = is_array( $cost_includes ?? '' ) ? implode( "\n", $cost_includes ) : (string) ( $cost_includes ?? '' );
                $sb_ci_lc = strtolower( $sb_ci );
                $sb_meal_title = '';
                if ( strpos( $sb_ci_lc, 'lunch' ) !== false && strpos( $sb_ci_lc, 'breakfast' ) !== false ) {
                    $sb_meal_title = __( 'Breakfast & Lunch included', 'fts' );
                } elseif ( strpos( $sb_ci_lc, 'lunch' ) !== false ) {
                    $sb_meal_title = __( 'Lunch included', 'fts' );
                } elseif ( strpos( $sb_ci_lc, 'breakfast' ) !== false ) {
                    $sb_meal_title = __( 'Breakfast included', 'fts' );
                } elseif ( strpos( $sb_ci_lc, 'meal' ) !== false ) {
                    $sb_meal_title = __( 'Meals included', 'fts' );
                }
                if ( $sb_meal_title !== '' ) {
                    $sb_items[] = array(
                        'icon' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"/><path d="M7 2v20"/><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3zm0 0v7"/></svg>',
                        'text' => $sb_meal_title,
                    );
                }
            ?>
            <?php if ( ! empty( $sb_items ) ) : ?>
            <div class="fts-v2-booking-trust fts-v2-sidebar-highlights">
                <?php foreach ( $sb_items as $sbi ) : ?>
                <div class="fts-v2-booking-trust-item">
                    <?php echo $sbi['icon']; ?>
                    <?php echo esc_html( $sbi['text'] ); ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- 7. CTA Button -->
            <div class="fts-v2-booking-cta">
                <button type="button" class="fts-v2-check-btn fts-bm-trigger"><?php echo esc_html__( 'Check availability', 'fts' ); ?></button>
            </div>

            <?php
                $sb_benefits = function_exists( 'fts_v2_build_booking_benefits' )
                    ? fts_v2_build_booking_benefits(
                        (string) ( $free_cancellation_text ?? '' ),
                        intval( $cancel_hours ?? 0 ),
                        ! empty( $pp_eligible ),
                        (string) ( $pay_later_text ?? '' ),
                        (string) ( $terms_url ?? '' ),
                        intval( $trip_id ?? get_the_ID() ),
                        isset( $trip_facts_items ) && is_array( $trip_facts_items ) ? $trip_facts_items : array(),
                        isset( $at_a_glance ) && is_array( $at_a_glance ) ? $at_a_glance : array()
                    )
                    : array();
                $sb_benefit_icon = function_exists( 'fts_v2_benefit_check_svg' ) ? fts_v2_benefit_check_svg( 24 ) : '';
            ?>
            <?php if ( ! empty( $sb_benefits ) ) : ?>
            <div class="fts-v2-sidebar-benefits">
                <?php foreach ( $sb_benefits as $sb_ben ) : ?>
                <div class="fts-v2-sidebar-benefit-item">
                    <span class="fts-v2-sidebar-benefit-icon" aria-hidden="true"><?php echo $sb_benefit_icon; ?></span>
                    <span class="fts-v2-sidebar-benefit-text">
                        <span class="fts-v2-sidebar-benefit-title"><?php echo esc_html( $sb_ben['title'] ); ?></span>
                        <span class="fts-v2-sidebar-benefit-desc">
                            <?php echo esc_html( $sb_ben['desc'] ); ?>
                            <?php if ( ! empty( $sb_ben['readMore'] ) && ! empty( $terms_url ) ) : ?>
                            <a href="<?php echo esc_url( $terms_url ); ?>" class="fts-v2-sidebar-benefit-more" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Read more', 'fts' ); ?></a>
                            <?php endif; ?>
                        </span>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- 9. Payment Icons (SVG) -->
            <div class="fts-v2-payment-icons">
                <svg class="fts-v2-pay-icon" viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="Visa"><rect width="38" height="24" rx="3" fill="#1a1f71"/><text x="19" y="15.5" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-size="10" font-weight="700" font-style="italic">VISA</text></svg>
                <svg class="fts-v2-pay-icon" viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="Mastercard"><rect width="38" height="24" rx="3" fill="#252525"/><circle cx="15" cy="12" r="7" fill="#eb001b"/><circle cx="23" cy="12" r="7" fill="#f79e1b"/><path d="M19 6.7a7 7 0 0 1 0 10.6 7 7 0 0 1 0-10.6z" fill="#ff5f00"/></svg>
                <svg class="fts-v2-pay-icon" viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="PayPal"><rect width="38" height="24" rx="3" fill="#f5f7fa"/><text x="19" y="15" text-anchor="middle" fill="#003087" font-family="Arial,sans-serif" font-size="8.5" font-weight="700">Pay<tspan fill="#009cde">Pal</tspan></text></svg>
                <svg class="fts-v2-pay-icon" viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="Stripe"><rect width="38" height="24" rx="3" fill="#635bff"/><text x="19" y="15" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-size="9" font-weight="700">stripe</text></svg>
            </div>
        </div>

        <?php if ( $enquiry_enabled === 'on' ) : ?>
        <div class="fts-v2-enquiry-card">
            <h4><i class="fa fa-comments-o"></i> <?php echo esc_html__( 'Have a Question?', 'fts' ); ?></h4>
            <p><?php echo esc_html__( 'Our travel experts are here to help.', 'fts' ); ?></p>
            <?php echo do_shortcode( '[WP_TRAVEL_ENGINE_TRIP_ENQUIRY_FORM use_current="yes"]' ); ?>
        </div>
        <?php endif; ?>

    </div>
</div>
